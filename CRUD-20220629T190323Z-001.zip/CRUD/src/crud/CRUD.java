package crud;
public class CRUD {

    public static void main(String[] args) {
    }
    
}
